//
//  IQPhotoEditorController.h
//  IQPhotoEditor.framework
//
//  Created by Mohd Iftekhar Qurashi on 01/07/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^IQPhotoEditorCompletion)(UIImage* image, BOOL isModified);

@interface IQPhotoEditorController : UIViewController

@property (nonatomic, strong, readonly) UIImage *image;

- (id)initWithImage:(UIImage *)image;

@end


@interface UIViewController (PresentPhotoEditor)

-(void)presentPhotoEditor:(IQPhotoEditorController*)editor withCompletion:(IQPhotoEditorCompletion)completion;

@end