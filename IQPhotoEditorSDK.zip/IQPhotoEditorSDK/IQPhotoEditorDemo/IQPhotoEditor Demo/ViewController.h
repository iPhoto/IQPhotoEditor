//
//  ViewController.h
//  IQPhotoEditor Demo
//
//  Created by Iftekhar on 07/07/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
